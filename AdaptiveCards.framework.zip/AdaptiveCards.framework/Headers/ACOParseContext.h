//
//  ACOParseContext.h
//  ACOParseContext
//
//  Copyright © 2019 Microsoft. All rights reserved.
//

#include <Foundation/Foundation.h>

@interface ACOParseContext : NSObject

- (instancetype)init;

@end

//
//  ACRBaseActionElementRenderer
//  ACRBaseActionElementRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//
#import "ACRIBaseActionElementRenderer.h"
#import <Foundation/Foundation.h>

@interface ACRBaseActionElementRenderer : NSObject <ACRIBaseActionElementRenderer>

@end

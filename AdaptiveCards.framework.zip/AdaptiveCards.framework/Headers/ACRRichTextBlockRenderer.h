//
//  ACRRichTextBlockRenderer
//  ACRRichTextBlockRenderer.h
//
//  Copyright © 2019 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRRichTextBlockRenderer : ACRBaseCardElementRenderer

+ (ACRRichTextBlockRenderer *)getInstance;
@end
